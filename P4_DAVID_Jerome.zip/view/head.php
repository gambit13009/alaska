<head>
	<meta charset="utf-8">
	<title>Billet simple pour l'Alaska</title>
	<!--Open Graph data-->
    <meta property="og:title" content="Billet simple pour l'Alaska" />
    <meta property="og:type" content="website" />
    <meta property="og:description" content="Billet simple pour l'Alaska Un roman de Jean Forteroche" />
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="css/bootstrap-reboot.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>