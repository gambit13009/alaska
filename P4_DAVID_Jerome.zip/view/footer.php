<!--Footer-->
<footer>
    <div class="footer-inner">
		<div class="row">
            <div class="container footer-area">
                <div class="col-md-9 col-sm-12 footer-area" role="complementary">
                <div id="nav_menu-4" class="footer_menu">
                    <a href="index.php?action=mentionslegales"><h2 class="footer-title">Mentions légales</h2></a>
                </div>		
                </div>
                <div class="site-info col-sm-6">
				<div class="copyright-text">
					Copyright © 2020. <br />Réalisé par Jérôme DAVID pour OpenClassrooms.				
                </div>
			</div>
	       </div>
		</div>
	</div>
        
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="https://cdn.tiny.cloud/1/ccocp9mhg9jtkqu6n0kobmpx1cp45o4h6xlv1jihacrx9rfi/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  <script>
    tinymce.init({
    selector: '#tinymce'
    });
  </script>
</footer>


